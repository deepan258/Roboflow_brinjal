# brinjal_leaf_spot > 2024-11-12 1:49pm
https://universe.roboflow.com/mefinalyear/brinjal_leaf_spot

Provided by a Roboflow user
License: CC BY 4.0

